Author: Malikah Bain
Date: 08-12-2024
Class: COMS 2200A

DESCRIPTION OF FILES:
These are the constituent tables of the database.

Route - a set of stops that buses travel along, directionless, e.g. Route 2
Trip - an instance of travelling along a route in a particular direction, e.g. Route 2, Greenboro
Vehicle - the bus

1. stops.csv
This is all the data collected about bus arrivals at all the stops.
Fields:
trip_stop_id - serial primary key, unique
stop_id  - unique id associated with the bus stop         
stop_name - name of the bus stop
trip_id - unique id associated with trips
stop_sequence - the order in which this stop is visited on a trip, e.g., Heron is the 4th stop (stop sequence 4) on a Route 2 trip in the Greenboro direction.
vehicle_id - unique id of vehicle
direction_id  - direction of the trip, e.g.,Route 2 to Greenboro vs Route 2 to Bayview.
day - day that the stop gets visited.
sch_arrival_time - the planned arrival time for the bus to reach the stop
sch_departure_time - the planed departure time of the bus from the stop
act_arrival_time - the actual arrival time of the bus at the stop
act_departure_time - the actual departure time of the bus from the stop
route_id - the id of the route, e.g, Route 2
schedule_relationship - the status of the bus relative to the schedule (canceled, scheduled, etc).
delay - the difference between the scheduled arrival time an the actual arrival time
on_time_performance - a label indicating if the bus is late, on-time, or early.
stop_lat - latitude of the stop
stop_lon - longitude of the stop
geom     - stores spatial data in a Euclidean system (just another format of storing the location of the stops).

2. filtered_stops.csv
The data about bus arrivals filtered to only include data in collected in Ward 17. This is the data used to create the visualizations.
Fields:
trip_stop_id - serial primary key, unique
stop_id  - unique id associated with the bus stop         
stop_name - name of the bus stop
trip_id - unique id associated with trips
stop_sequence - the order in which this stop is visited on a trip, e.g., Heron is the 4th stop (stop sequence 4) on a Route 2 trip in the Greenboro direction.
vehicle_id - unique id of vehicle
direction_id  - direction of the trip, e.g.,Route 2 to Greenboro vs Route 2 to Bayview.
day - day that the stop gets visited.
sch_arrival_time - the planned arrival time for the bus to reach the stop
sch_departure_time - the planed departure time of the bus from the stop
act_arrival_time - the actual arrival time of the bus at the stop
act_departure_time - the actual departure time of the bus from the stop
route_id - the id of the route, e.g, Route 2
schedule_relationship - the status of the bus relative to the schedule (canceled, scheduled, etc).
delay - the difference between the scheduled arrival time an the actual arrival time
delay_seconds - delay but measured in seconds.
on_time_performance - a label indicating if the bus is late, on-time, or early.
stop_lat - latitude of the stop
stop_lon - longitude of the stop
geom     - stores spatial data in a Euclidean system (just another format of storing the location of the stops).

3. routes.csv
Fields
route_id: id of route
route_name: name of route

4. trips.csv
trip_id: unique id associated with trips
route_id: id of route
direction_id: id indicating the direction the trip is going on a route
vehicle_id - unique id of vehicle
start_date: the day the trip starts in YYYY-MM-DD format

5. vehicle_performance.csv
vehicle_id: unique id of vehicle
license_plate: the license plate of the vehicle
route_id: id of route
trip_id: unique id associated with trips

6. w17_shapefile.csv
Geometric data of Ward 17's shapefile converted to database format, retrieved from https://open.ottawa.ca/datasets/ottawa::wards-2022-2026/explore.





      
